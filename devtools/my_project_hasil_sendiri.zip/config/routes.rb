Rails.application.routes.draw do
  devise_for :users
  # root :to => "posts#index" # ini untuk mengakses
  #root 'muhammad#index'
  root :to => "muhammad#essa" # ini untuk mengakses home dengan method index
  resources :posts
  get 'muhammad/essa'

  # root 'muhammad#essa' # 

  get 'muhammad/welcome'

  get 'muhammad/login'

  get 'muhammad/arrayLoop'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
