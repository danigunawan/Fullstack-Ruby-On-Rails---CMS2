class Section < ApplicationRecord
end
