class SectionEdit < ApplicationRecord
end
