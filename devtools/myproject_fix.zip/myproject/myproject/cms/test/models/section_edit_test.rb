require 'test_helper'

class SectionEditTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
