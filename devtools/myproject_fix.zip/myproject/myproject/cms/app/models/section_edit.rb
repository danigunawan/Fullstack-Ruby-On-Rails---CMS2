class SectionEdit < ApplicationRecord


    belongs_to :admin_user
    belongs_to :section
   # has_and_belongs_to_many :section


end
