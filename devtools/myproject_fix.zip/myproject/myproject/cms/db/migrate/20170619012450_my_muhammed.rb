class MyMuhammed < ActiveRecord::Migration[5.1]
  # def change
  # end



  def up
  end



    def down
  end

 
end
