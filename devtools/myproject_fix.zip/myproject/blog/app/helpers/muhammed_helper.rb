module MuhammedHelper
end
