class MuhammedController < ApplicationController
end
