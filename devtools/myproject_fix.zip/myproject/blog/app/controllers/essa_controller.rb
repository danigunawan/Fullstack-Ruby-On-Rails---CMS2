class EssaController < ApplicationController
end
